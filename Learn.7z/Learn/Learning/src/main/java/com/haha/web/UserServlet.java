package com.haha.web;

import com.alibaba.fastjson.JSON;
import com.haha.pojo.User;
import com.haha.service.UserService;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;

@WebServlet("/user/*")
public class UserServlet extends BaseServlet {

    public void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        BufferedReader br = req.getReader();
        String json=br.readLine();
        User user= JSON.parseObject(json,User.class);
        UserService userService=new UserService();

        User u= userService.login(user);
        if(u!=null){
            resp.getWriter().write(JSON.toJSONString(u));

        }
        else{
            resp.getWriter().write("fail");
        }

    }


}
