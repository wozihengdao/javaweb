package com.haha.web;

import com.alibaba.fastjson.JSON;
import com.haha.pojo.Kind;
import com.haha.pojo.Store;
import com.haha.service.KindService;
import com.haha.service.StoreService;
import com.haha.pojo.Kind;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;

@WebServlet("/kind/*")
public class KindServlet extends BaseServlet {
    KindService service=new KindService();
    public void selectAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        List<Kind> list= service.selectAll();
        String s= JSON.toJSONString(list);
        resp.getWriter().write(s);

    }

    public void insert(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html;charset=utf-8");

        BufferedReader reader = req.getReader();
        String json= reader.readLine();

        Kind kind= JSON.parseObject(json, com.haha.pojo.Kind.class);
        System.out.println(json);
        service.insert(kind);
        resp.getWriter().write("success");

    }

    public void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html;charset=utf-8");

        BufferedReader reader = req.getReader();
        String json= reader.readLine();

        Kind kind= JSON.parseObject(json, com.haha.pojo.Kind.class);
        System.out.println(json);
        service.deleteById(kind.getId());
        resp.getWriter().write("success");

    }

    public void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.setContentType("text/html;charset=utf-8");

        BufferedReader reader = req.getReader();
        String json= reader.readLine();

        Kind kind= JSON.parseObject(json, com.haha.pojo.Kind.class);
        System.out.println(json);
        service.update(kind);
        resp.getWriter().write("success");

    }


}
