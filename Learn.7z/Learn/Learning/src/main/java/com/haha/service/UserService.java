package com.haha.service;

import com.haha.mapper.StoreMapper;
import com.haha.mapper.UserMapper;
import com.haha.pojo.Store;
import com.haha.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class UserService {

    public User login(User user) throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserMapper userMapper = sqlSession.getMapper(com.haha.mapper.UserMapper.class);
        User user1=userMapper.Login(user);
        sqlSession.close();
        // System.out.println(user1);
        return user1;
    }




}
