package com.haha.mapper;

import com.haha.pojo.Bill;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface BillMapper {

    // 查询所有账单
    @Select("SELECT * FROM bill")
    List<Bill> selectAll();

    // 根据 ID 查询账单
    @Select("SELECT * FROM bill WHERE id = #{id}")
    Bill selectById(String id);

    // 插入账单
    @Insert("INSERT INTO bill (name, type, area, unit) VALUES ( #{name}, #{type}, #{area}, #{unit})")
    void insert(Bill bill);

    // 更新账单
    @Update("UPDATE bill SET name = #{name}, type = #{type}, area = #{area}, unit = #{unit} WHERE id = #{id}")
    void update(Bill bill);

    // 根据 ID 删除账单
    @Delete("DELETE FROM bill WHERE id = #{id}")
    void deleteById(String id);




}
