package com.haha.service;

import com.haha.mapper.BillMapper;
import com.haha.mapper.StoreMapper;
import com.haha.pojo.Bill;
import com.haha.pojo.Store;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class BillServlet {


    private static final String CONFIG_FILE = "mybatis-config.xml";

    // 查询所有账单
    public List<Bill> selectAll() throws IOException {

        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        BillMapper billMapper = sqlSession.getMapper(com.haha.mapper.BillMapper.class);
        List<Bill> list=billMapper.selectAll();
        sqlSession.close();

        return list;
        
    }

    // 根据 ID 查询账单
//    public Bill selectById(String id) throws IOException {
//        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
//            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
//            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
//                BillMapper billMapper = sqlSession.getMapper(BillMapper.class);
//                return billMapper.selectById(id);
//            }
//        }
//    }

    // 插入账单
    public void insert(Bill Bill) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                BillMapper billMapper = sqlSession.getMapper(BillMapper.class);
                 billMapper.insert(Bill);
                sqlSession.commit();
               
            }
        }
    }

    // 更新账单
    public void update(Bill Bill) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                BillMapper billMapper = sqlSession.getMapper(BillMapper.class);
                billMapper.update(Bill);
                sqlSession.commit();
            
            }
        }
    }

    // 根据 ID 删除账单
    public void deleteById(String id) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                BillMapper billMapper = sqlSession.getMapper(BillMapper.class);
                 billMapper.deleteById(id);
                sqlSession.commit();
              
            }
        }
    }


}
