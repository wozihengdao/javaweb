package com.haha.mapper;

import com.haha.pojo.Bill;
import com.haha.pojo.Kind;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface KindMapper {

    @Select("SELECT * FROM kind")
    List<Kind> selectAll();
//
//    /**
//     * 根据 ID 查询种类信息
//     * @param id 种类 ID
//     * @return 对应的种类信息
//     */
//    @Select("SELECT * FROM kind WHERE id = #{id}")
//    Kind selectById(String id);

    /**
     * 插入种类信息
     * @param kind 种类信息对象
     * @return 插入成功的记录数
     */
    @Insert("INSERT INTO kind ( name, size, material) VALUES ( #{name}, #{size}, #{material})")
    void insert(Kind kind);

    /**
     * 更新种类信息
     * @param kind 种类信息对象
     * @return 更新成功的记录数
     */
    @Update("UPDATE kind SET name = #{name}, size = #{size}, material = #{material} WHERE id = #{id}")
    void update(Kind kind);

    /**
     * 根据 ID 删除种类信息
     * @param id 种类 ID
     * @return 删除成功的记录数
     */
    @Delete("DELETE FROM kind WHERE id = #{id}")
    void deleteById(String id);

}
