package com.haha.service;

import com.haha.mapper.StoreMapper;
import com.haha.mapper.UserMapper;
import com.haha.pojo.Store;
import com.haha.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class StoreService {

   public List<Store> selectAll() throws IOException {

        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = sqlSessionFactory.openSession();
        StoreMapper storeMapper = sqlSession.getMapper(com.haha.mapper.StoreMapper.class);
         List<Store> list=storeMapper.selectAll();
        sqlSession.close();

        return list;
    }

    public void update(Store store) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml")) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                StoreMapper storeMapper = sqlSession.getMapper(StoreMapper.class);
                storeMapper.update(store);
                sqlSession.commit();

            }
        }
    }

    public void deleteById(String id) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml")) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                StoreMapper storeMapper = sqlSession.getMapper(StoreMapper.class);
                storeMapper.deleteById(id);
                sqlSession.commit();
            }
        }
    }

    public void insert(Store store) throws IOException {
        try (InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml")) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                StoreMapper storeMapper = sqlSession.getMapper(StoreMapper.class);
                storeMapper.insert(store);
                sqlSession.commit();
            }
        }
    }



}
