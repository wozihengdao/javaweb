package com.haha.service;

import com.haha.mapper.KindMapper;

import com.haha.pojo.Kind;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;


public class KindService {
    private static final String CONFIG_FILE = "mybatis-config.xml";
    // 插入种类信息

    public List<Kind> selectAll(){
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                KindMapper kindMapper = sqlSession.getMapper(KindMapper.class);
                kindMapper.selectAll();
                sqlSession.commit();

                return kindMapper.selectAll();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 插入种类信息
    public void insert(Kind kind) {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                KindMapper kindMapper = sqlSession.getMapper(KindMapper.class);
                kindMapper.insert(kind);
                sqlSession.commit();

            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    // 更新种类信息
    public void update(Kind kind) {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                KindMapper kindMapper = sqlSession.getMapper(KindMapper.class);
              kindMapper.update(kind);
                sqlSession.commit();

            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    // 根据 ID 删除种类信息
    public void deleteById(String id) {
        try (InputStream inputStream = Resources.getResourceAsStream(CONFIG_FILE)) {
            SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
            try (SqlSession sqlSession = sqlSessionFactory.openSession()) {
                KindMapper kindMapper = sqlSession.getMapper(KindMapper.class);
                 kindMapper.deleteById(id);
                sqlSession.commit();

            }
        } catch (IOException e) {
            e.printStackTrace();

        }
    }
}
