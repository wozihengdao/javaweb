package com.haha.mapper;

import com.haha.pojo.Store;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface StoreMapper {

    @Select("select * from store")
    List<Store> selectAll();

    @Insert("INSERT INTO store (name) VALUES (#{name})")
    void insert(Store store);

    @Update("UPDATE store SET name = #{name} WHERE id = #{id}")
    void update(Store store);

    @Delete("DELETE FROM store WHERE id = #{id}")
    void deleteById(String id);




}
