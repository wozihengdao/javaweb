export * from './element-ui'

import * as ElementUI from './element-ui'
export default ElementUI
